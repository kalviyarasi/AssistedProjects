package com.example.demo;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class NewTest {
	WebDriver wd;
@BeforeTest
public void config() {
	WebDriverManager.chromedriver().setup();
	wd=new ChromeDriver();
	wd.manage().window().maximize();	
	}
	@AfterTest
	public void quitbrowser() {
		wd.quit();
	}
  @Test
  public void test() {
	  wd.get("http://ec2-44-202-117-222.compute-1.amazonaws.com:8088/");
	  wd.findElement(By.name("empname")).sendKeys("degi");
	  wd.findElement(By.name("empemail")).sendKeys("degi@yahoo.com");
	  wd.findElement(By.name("age")).sendKeys("21");
	  wd.findElement(By.xpath("/html/body/form/input[4]")).click();
	  
	  String text=wd.findElement(By.xpath("/html/body/h1")).getText();
	  System.out.println(text);
	  assertEquals(text,"insertion is successfull....");  
  }
}
