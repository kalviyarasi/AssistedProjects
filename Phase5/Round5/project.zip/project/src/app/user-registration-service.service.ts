import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class UserRegistrationServiceService {
 
  constructor(private http:HttpClient) { }
 
  public doRegistration(user:any){
    return this.http.post("http://localhost:8088/register",user,{responseType:'text' as 'json'})
  }
 
 public getUsers(){
return this.http.get("http://localhost:8088/getAllUsers");
 }
 
 
 public getUserByEmail(email:any){
return  this.http.get("http://localhost:8088/finduser/"+email);
 
 }
 
 
 public deleteUser(id:any){
  return  this.http.delete("http://localhost:8088/cancel/"+id);
 
 }
 
}
 


