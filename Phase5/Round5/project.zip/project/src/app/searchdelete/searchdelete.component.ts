import { Component, OnInit } from '@angular/core';
import { UserRegistrationServiceService } from '../user-registration-service.service';
 
@Component({
  selector: 'app-searchdelete',
  templateUrl: './searchdelete.component.html',
  styleUrls: ['./searchdelete.component.css']
})
export class SearchdeleteComponent implements OnInit {
email:string;
users:any;
  constructor(private service:UserRegistrationServiceService) { }
 
  ngOnInit(): void {
    let resp=this.service.getUsers();
    resp.subscribe((data:any)=>this.users=data);
  }
 
 
 
public findUserByEmail(){
let resp=this.service.getUserByEmail(this.email);
resp.subscribe((data:any)=>this.users=data);
}
 
 
public deleteUser(id:number){
  let resp=this.service.deleteUser(id);
  resp.subscribe((data:any)=>this.users=data);
}
 
 
}
